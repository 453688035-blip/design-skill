---
name: google-design-system
description: Provides authoritative guidance on Google's design system — covering Material Design 3 (M3) visual styles, color tokens, typography, shape, motion, interaction states, component guidelines, and Google code style conventions across HTML/CSS, JavaScript, TypeScript, Python, Go, Shell, C#, Objective-C, and R. Use when the user asks to design UI, apply color/token systems, choose components, define interaction states, or write/review code style.
---

# Google Design System

## Critical Instructions

- **Dual scope**: This skill covers both **Material Design 3** (visual/UI system) and **Google Code Style Guides** (code authoring conventions). Apply whichever is relevant to the user's request — or both.
- **Token-first**: Always recommend design token references (`md.sys.*`, `md.ref.*`, `md.comp.*`) over hardcoded values.
- **Consistency rule**: When the user's codebase already has a style, match it before introducing new patterns.

---

## Core Design Principles

### Material Design 3 (m3.material.io)
> *"An adaptable system of guidelines, components, and tools supporting best practices of user interface design."*

- **Design with emotion** — vibrant color, physics-based motion, expressive typography, contrasting shapes
- **Adaptable** — scales across wearables → TVs; supports light/dark themes and dynamic color
- **Accessible by default** — every color role, state, and type style is built for WCAG compliance
- **Token-driven** — all style decisions flow through a three-tier token model

### Google Code Style
| Principle | Meaning |
|---|---|
| **Clarity** | Code's purpose is self-evident to the reader |
| **Simplicity** | Simplest correct solution; complexity must be justified |
| **Concision** | High signal-to-noise; no redundant code or comments |
| **Maintainability** | Written to be easily evolved; docs updated with code |
| **Consistency** | Conform to the surrounding codebase — "Be consistent" closes every guide |

> **Optimize for the reader, not the writer.**

---

## Color System

*Reference: https://m3.material.io/styles/color/overview*

### Color Role Groups
| Group | Key Roles | Typical Usage |
|---|---|---|
| **Primary** | `primary`, `on-primary`, `primary-container`, `on-primary-container` | FABs, prominent buttons, key actions |
| **Secondary** | `secondary`, `on-secondary`, `secondary-container`, `on-secondary-container` | Filters, less prominent actions |
| **Tertiary** | `tertiary`, `on-tertiary`, `tertiary-container`, `on-tertiary-container` | Accent contrast, decorative moments |
| **Error** | `error`, `on-error`, `error-container`, `on-error-container` | Destructive actions, validation |
| **Surface** | `surface`, `surface-variant`, `surface-container-*`, `inverse-surface` | Backgrounds, cards, sheets |
| **Outline** | `outline`, `outline-variant` | Borders, dividers |

### Dynamic Color
- **User-generated**: derived from wallpaper (Android 12+)
- **Content-based**: derived from imagery or brand hue
- **Baseline**: static default when dynamic color is unavailable

### Key Rules
- Always pair a color role with its `on-*` counterpart for text/icons.
- Three contrast levels are tokenized: **Standard**, **Medium**, **High**.
- Fixed roles (`primary-fixed`, etc.) stay constant across light and dark themes.
- Tone-based surface tints replace elevation overlays from M2.

### CSS Color Conventions (Google Style Guide)
- Use 3-character hex shorthand where possible: `#ebc` not `#eebbcc`
- Always lowercase hex values: `#e5e5e5`, not `#E5E5E5`
- No `!important` for color overrides — use specificity or cascade

---

## Typography

*Reference: https://m3.material.io/styles/typography/overview*

### Type Scale — 30 Styles (15 baseline + 15 emphasized)

| Role | Sizes | Usage |
|---|---|---|
| **Display** | Large, Medium, Small | Hero moments, editorial |
| **Headline** | Large, Medium, Small | Section headers |
| **Title** | Large, Medium, Small | Component titles, dialogs |
| **Body** | Large, Medium, Small | Long-form reading |
| **Label** | Large, Medium, Small | UI labels, captions, buttons |

Emphasized variants add visual weight for highlighted moments (e.g. `display-large-emphasized`).

### Typefaces
- **Roboto Flex** — variable font (weight, width, grade, slant, optical size); preferred for expressive UI
- **Roboto Serif** — variable serif for editorial
- **Roboto Mono** — monospace for code/data

### Typography Token Structure
`md.sys.typescale.<role>.<attribute>`

Attributes: `font`, `line-height`, `size`, `tracking`, `weight`

Example: `md.sys.typescale.body-large.font`, `md.sys.typescale.label-medium.size`

---

## Shape System

*Reference: https://m3.material.io/styles/shape/overview-principles*

### Corner Radius Scale
| Token | Value | Example |
|---|---|---|
| `shape.corner.none` | 0dp | Banners, full-bleed |
| `shape.corner.extra-small` | 4dp | Tooltips |
| `shape.corner.small` | 8dp | Cards, chips |
| `shape.corner.medium` | 12dp | Dialogs, sheets |
| `shape.corner.large` | 16dp | Navigation drawers |
| `shape.corner.large-increased` | 20dp | M3 Expressive |
| `shape.corner.extra-large` | 28dp | FABs |
| `shape.corner.extra-large-increased` | 32dp | M3 Expressive |
| `shape.corner.extra-extra-large` | 48dp | M3 Expressive |
| `shape.corner.full` | 50% | Buttons, badges, switches |

### Shape Principles
- Shape and typography should echo each other's roundness.
- **Shape morphing** communicates interaction states (selected, loading, etc.).
- **Tension through contrast** — combine square and rounded shapes for dynamism.
- Shape is NOT semantic — avoid assigning a fixed meaning to a specific shape.
- Use abstract shapes **sparingly**; don't compromise clarity for decoration.

---

## Elevation

| Level | Surface Tint | Usage |
|---|---|---|
| Level 0 | No tint | Base surface |
| Level 1 | +5% primary | Cards, menus |
| Level 2 | +8% primary | Navigation drawers |
| Level 3 | +11% primary | FABs |
| Level 4 | +12% primary | Pinned top app bar |
| Level 5 | +14% primary | Open bottom sheets |

Tone-based surface tints are the primary elevation signal; drop shadows are supplementary.

---

## Motion & Interaction

*Reference: https://m3.material.io/styles/motion/overview*

### Motion Schemes
| Scheme | Character | Use for |
|---|---|---|
| **Expressive** | Overshoots → bounces into place | Hero moments, key interactions, most UI |
| **Standard** | Smooth ease, minimal bounce | Utilitarian products, functional transitions |

### Spring Tokens
Token: `md.sys.motion.spring.<speed>.<style>`

| Style | Behavior |
|---|---|
| **Spatial** | position, rotation, size, corners — overshoot intentional |
| **Effects** | color, opacity — no overshoot |

| Speed | Use |
|---|---|
| **Fast** | Small components: buttons, switches, chips |
| **Default** | Standard transitions: bottom sheets, navigation |
| **Slow** | Full-screen or large layout transitions |

### CSS Interaction Rules
- State changes (hover, focus, active) → CSS only; never inline `style=""` or JS-injected styles.
- Toggle state via CSS class changes from JS; the visual output belongs in CSS.
- No `!important` for state overrides.

---

## Interaction States

*Reference: https://m3.material.io/foundations/interaction-states*

| State | Trigger | Visual indicator |
|---|---|---|
| **Enabled** | Default | Full color + contrast |
| **Disabled** | Inoperable | 38% opacity content, 12% opacity container |
| **Hover** | Cursor over element | State layer 8% opacity |
| **Focused** | Keyboard/voice highlight | Focus ring + state layer 10% |
| **Pressed** | Tap / click | Ripple + state layer 10–12% |
| **Dragged** | Press and move | Elevated shadow + state layer 16% |

- State layers use the component's `on-*` color role.
- States can be **combined** (e.g. selected + hover).
- Apply states **consistently** across all components in a product.
- Every state must have **two** distinguishable visual indicators for accessibility.

---

## Design Tokens

*Reference: https://m3.material.io/foundations/design-tokens/overview*

### Three Token Classes

#### 1. Reference Tokens (`md.ref.*`)
All available options — static values, palette of choices.
- `md.ref.palette.primary40` → `#6750A4`
- `md.ref.typeface.plain-medium` → `Roboto Medium`

#### 2. System Tokens (`md.sys.*`)
Design decisions — map reference tokens to roles; change with context (light/dark, device).
- `md.sys.color.primary` → `md.ref.palette.primary40` (light theme)
- `md.sys.typescale.body-large.size` → `16sp`
- `md.sys.motion.spring.fast.spatial`

#### 3. Component Tokens (`md.comp.*`)
Style properties for specific component elements, grouped by state then element.
- `md.comp.filled-button.container.color`
- `md.comp.fab.primary.container.color`

### Token Naming Structure
```
md  .  sys  .  color  .  secondary-container
│      │        │          └─ Role / purpose
│      │        └─ Category (color, typescale, shape, motion…)
│      └─ Token class: ref | sys | comp
└─ System prefix ("md" = Material Design)
```

### Token Contexts
The same system token resolves to different reference tokens depending on:
light/dark theme · device form factor · dense layout · RTL writing direction

---

## Components

*Reference: https://m3.material.io/components*

### Buttons
| Component | Use |
|---|---|
| Filled / Outlined / Text / Elevated / Tonal Button | Primary and secondary actions |
| Button Groups | Related buttons with shape-shifting layout |
| FAB / Extended FAB | Most important action on screen |
| FAB Menu | FAB expanding into related actions |
| Icon Button | Compact toggle or action |
| Segmented Button | Select from 2–5 options |
| Split Button | Button + connected related-action menu |

### Navigation
| Component | Use |
|---|---|
| Navigation Bar | Bottom nav, 3–5 destinations (mobile) |
| Navigation Drawer | Side panel for many destinations (tablet/desktop) |
| Navigation Rail | Compact side nav (tablet/desktop) |

### Containment & Display
| Component | Use |
|---|---|
| Cards | Contained, related content |
| Dialo               gs | Time-critical decisions |
| Bottom Sheets / Side Sheets | Supplementary overlay content |
| Carousel | Horizontally browsable collection |
| Lists | Vertically grouped items |

### Input & Selection
| Component | Use |
|---|---|
| Checkbox | Multi-select |
| Radio Button | Single select |
| Switch | Toggle a single setting |
| Sliders | Continuous range selection |
| Chips | Input, filtering, or compact actions |
| Menus | Temporary list of choices |
| Search | Query bar with suggestions |

### Communication & Progress
| Component | Use |
|---|---|
| Progress Indicators (linear, circular) | Ongoing process status |
| Loading Indicator | Expressive loading (M3 Expressive) |
| Snackbar | Brief, non-blocking messages |
| Badges | Numeric or status markers on icons |

### Structure
| Component | Use |
|---|---|
| App Bars (top, bottom) | Navigation + contextual actions |
| Tabs | Horizontal within-page navigation |
| Toolbars | Flexible action bar (M3 Expressive) |
| Date / Time Pickers | Calendar / clock selection |
| Divider | Visual separation |

---

## Layout & Accessibility

### Layout
- Use a **fluid grid** with responsive breakpoints: compact / medium / expanded.
- Components change form at breakpoints (e.g. navigation bar → navigation rail on tablets).
- Base all spacing on the **4dp grid** — use multiples of 4.

### Accessibility
- Every interactive element reachable via keyboard and assistive technologies.
- Minimum touch target: **48×48dp**.
- Color is **never** the sole indicator of meaning — always pair with shape, text, or icon.
- WCAG AA contrast: 4.5:1 (normal text), 3:1 (large text).
- Visible focus rings on all interactive elements.

---

## Code Style — Universal Rules

| Rule | Guideline |
|---|---|
| Encoding | UTF-8, no BOM |
| Indentation | 2 spaces (HTML/CSS/JS/TS/C#) · 4 spaces (Python/Shell) · no tabs |
| Line length | 80 cols (Python, Markdown, Shell, Go) · 100 cols (C#) |
| Trailing whitespace | Always remove |
| TODOs | `TODO:` keyword only |
| File names | `kebab-case` (web) · `PascalCase` (C#) · `snake_case` (Python/Shell) |
| Comments | Explain *why*, not what |
| Protocol | Always `https:` in URLs |

---

## HTML / CSS Guidelines

### HTML Key Rules
- `<!doctype html>` always — no quirks mode
- `<meta charset="utf-8">` in every document
- Semantic elements: `<a>`, `<button>`, `<h1>`–`<h6>`, `<p>`
- `alt` on all `<img>`
- Structure → HTML · Presentation → CSS · Behavior → JS
- Prefer `class` for styling; `data-*` for scripting
- `id` values must contain a hyphen
- Double quotes for HTML attributes; all code lowercase; 2-space indent

### CSS Key Rules
- Class names reflect purpose: `.nav`, not `.blue-text`
- Hyphen-case only: `.video-id`
- No ID selectors (`#example {}`)
- No type-qualified selectors (`div.error` → `.error`)
- Shorthand properties always: `padding: 0 1em 2em`
- Omit units on zero: `margin: 0`
- Leading zeros: `font-size: 0.8em`
- 3-char hex where possible; always lowercase
- No `!important`
- One space after `:` in declarations; new line per selector and declaration; `;` after every declaration

---

## Language-Specific Style

### JavaScript / TypeScript
- TypeScript preferred for all new projects
- Source order: copyright → `@fileoverview` → imports → implementation
- Encoding: UTF-8 · No tabs · Use actual Unicode chars for printable symbols
- ES modules (`import`/`export`) for all new code
- Type annotations are first-class in TypeScript

### Python
| Rule | Detail |
|---|---|
| Linter | `pylint` with Google `pylintrc` |
| Imports | `import module`; no wildcard imports |
| Indentation | 4 spaces |
| Names | `snake_case` vars/funcs · `PascalCase` classes · `UPPER_SNAKE_CASE` constants |
| Docstrings | Required for all public symbols |

### Go (priority order)
1. Clarity → 2. Simplicity → 3. Concision → 4. Maintainability → 5. Consistency
- No `Get` prefix on getters: `Name()` not `GetName()`
- Avoid repeating package name in function names
- Prefer core language constructs before adding dependencies

### Shell / Bash
- Only `#!/bin/bash`; no SUID/SGID
- 2-space indent · 80-char lines · errors to STDERR
- `snake_case` functions and locals · `UPPER_SNAKE_CASE` constants

### C#
- `PascalCase` classes/methods · `camelCase` locals · `_camelCase` private fields · `IInterface` prefix
- 2-space indent · 100-char limit · braces always required

### Objective-C
- Optimize for the reader; follow Cocoa naming guidelines
- `/** */` block comments on all interfaces, categories, and protocols

### R
- `BigCamelCase` functions · `.DotBigCamelCase` private functions
- Always use `<-` assignment; always explicit `return()`
- Qualify all external calls: `purrr::map()`

---

## Naming Conventions Quick Reference

| Language | Variables | Functions | Classes | Constants | Files |
|---|---|---|---|---|---|
| HTML/CSS | `kebab-case` (classes) | — | — | — | `kebab-case.html` |
| JavaScript | `camelCase` | `camelCase` | `PascalCase` | `UPPER_SNAKE_CASE` | `kebab-case.js` |
| TypeScript | `camelCase` | `camelCase` | `PascalCase` | `UPPER_SNAKE_CASE` | `kebab-case.ts` |
| Python | `snake_case` | `snake_case` | `PascalCase` | `UPPER_SNAKE_CASE` | `snake_case.py` |
| Go | `camelCase` | `camelCase`/`PascalCase` (exported) | `PascalCase` | `PascalCase` (exported) | `snake_case.go` |
| Shell | `snake_case` | `snake_case` | — | `UPPER_SNAKE_CASE` | `snake_case.sh` |
| C# | `camelCase`/`_camelCase` (private) | `PascalCase` | `PascalCase` | `PascalCase` | `PascalCase.cs` |
| Objective-C | `camelCase` | `camelCase` | `PascalCase` | `kPascalCase` | `PascalCase.m` |
| R | `snake_case` | `BigCamelCase` | — | — | `snake_case.R` |

---

## References

| Resource | URL |
|---|---|
| Material Design 3 | https://m3.material.io/ |
| M3 Color System | https://m3.material.io/styles/color/overview |
| M3 Typography | https://m3.material.io/styles/typography/overview |
| M3 Shape | https://m3.material.io/styles/shape/overview-principles |
| M3 Motion | https://m3.material.io/styles/motion/overview |
| M3 States | https://m3.material.io/foundations/interaction-states |
| M3 Tokens | https://m3.material.io/foundations/design-tokens/overview |
| M3 Components | https://m3.material.io/components |
| Google Style Guides | https://google.github.io/styleguide/ |
| Material Theme Builder | https://material-foundation.github.io/material-theme-builder/ |
| Figma M3 Design Kit | https://www.figma.com/community/file/1035203688168086460 |
